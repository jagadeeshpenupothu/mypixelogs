Elegant Plum Salon Letterhead Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/ravya-salon-letterhead)
Size: A4 letterhead, 210 × 297 mm.

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  ravya-salon-letterhead.psd  Photoshop / Photopea: double-click a text layer to edit it
  ravya-salon-letterhead.ai   Adobe Illustrator (every side is a page): click the text and type
  ravya-salon-letterhead.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  ravya-salon-letterhead.eps  CorelDRAW / older Illustrator (File > Import)
  ravya-salon-letterhead.pdf  Print-ready PDF
  ravya-salon-letterhead.png  300 dpi

Fonts: Montserrat 500 (Google Fonts, SIL Open Font License); Montserrat 600 (Google Fonts, SIL Open Font License); Cormorant Garamond 600 (Google Fonts, SIL Open Font License)

Free for personal and commercial use. Replace the sample text and logo with your own details.
