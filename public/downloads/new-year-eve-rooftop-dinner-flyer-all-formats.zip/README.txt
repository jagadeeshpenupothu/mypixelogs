New Year's Eve Rooftop Dinner Flyer Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/new-year-eve-rooftop-dinner-flyer)
Size: A4, 210 × 297 mm.

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  new-year-eve-rooftop-dinner-flyer.psd  Photoshop / Photopea: double-click a text layer to edit it
  new-year-eve-rooftop-dinner-flyer.ai   Adobe Illustrator (every side is a page): click the text and type
  new-year-eve-rooftop-dinner-flyer.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  new-year-eve-rooftop-dinner-flyer.eps  CorelDRAW / older Illustrator (File > Import)
  new-year-eve-rooftop-dinner-flyer.pdf  Print-ready PDF
  new-year-eve-rooftop-dinner-flyer.png  300 dpi

Fonts: Playfair Display 700 (Google Fonts, SIL Open Font License); Montserrat 500 (Google Fonts, SIL Open Font License); Great Vibes 400 (Google Fonts, SIL Open Font License); Playfair Display 800 (Google Fonts, SIL Open Font License); Montserrat 700 (Google Fonts, SIL Open Font License); Montserrat 600 (Google Fonts, SIL Open Font License)
Images: Generated with OpenAI image models for MyPixelogs (Free to use, OpenAI)

Free for personal and commercial use. Replace the sample text and logo with your own details.
