Vaikunta Ekadasi Temple Event Flyer Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/vaikunta-ekadasi-temple-flyer)
Size: A4, 210 × 297 mm.

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  vaikunta-ekadasi-temple-flyer.psd  Photoshop / Photopea: double-click a text layer to edit it
  vaikunta-ekadasi-temple-flyer.ai   Adobe Illustrator (every side is a page): click the text and type
  vaikunta-ekadasi-temple-flyer.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  vaikunta-ekadasi-temple-flyer.eps  CorelDRAW / older Illustrator (File > Import)
  vaikunta-ekadasi-temple-flyer.pdf  Print-ready PDF
  vaikunta-ekadasi-temple-flyer.png  300 dpi

Fonts: Montserrat 600 (Google Fonts, SIL Open Font License); Great Vibes 400 (Google Fonts, SIL Open Font License); Playfair Display 800 (Google Fonts, SIL Open Font License); Montserrat 500 (Google Fonts, SIL Open Font License); Montserrat 700 (Google Fonts, SIL Open Font License); Playfair Display 700 (Google Fonts, SIL Open Font License)
Images: Generated with OpenAI image models for MyPixelogs (Free to use, OpenAI)

Free for personal and commercial use. Replace the sample text and logo with your own details.
