Raleway
=======
Designer: Matt McInerney, Pablo Impallari, Rodrigo Fuenzalida
Licence: SIL Open Font License 1.1. Free for personal and commercial use, including print, logos and client work.
Source: Google Fonts (fonts.google.com/specimen/Raleway), downloaded from MyPixelogs (mypixelogs.netlify.app/assets/fonts/raleway).

How to install
- Windows: right-click the .ttf file and choose "Install" (or "Install for all users").
- Mac: double-click the .ttf file, then click "Install Font".
Then restart Photoshop, Illustrator, Word or Canva desktop and pick "Raleway" from the font list.
Files with [wght] in the name are variable fonts: one file holds every weight.
