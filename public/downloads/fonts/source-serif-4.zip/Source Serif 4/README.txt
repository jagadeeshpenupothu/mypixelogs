Source Serif 4
==============
Designer: Frank Grießhammer
Licence: SIL Open Font License 1.1. Free for personal and commercial use, including print, logos and client work.
Source: Google Fonts (fonts.google.com/specimen/Source+Serif+4), downloaded from MyPixelogs (mypixelogs.netlify.app/assets/fonts/source-serif-4).

How to install
- Windows: right-click the .ttf file and choose "Install" (or "Install for all users").
- Mac: double-click the .ttf file, then click "Install Font".
Then restart Photoshop, Illustrator, Word or Canva desktop and pick "Source Serif 4" from the font list.
Files with [wght] in the name are variable fonts: one file holds every weight.
