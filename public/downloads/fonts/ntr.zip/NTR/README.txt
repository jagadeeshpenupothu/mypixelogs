NTR
===
Designer: Purushoth Kumar Guttula
Licence: SIL Open Font License 1.1. Free for personal and commercial use, including print, logos and client work.
Source: Google Fonts (fonts.google.com/specimen/NTR), downloaded from MyPixelogs (mypixelogs.netlify.app/assets/fonts/ntr).

How to install
- Windows: right-click the .ttf file and choose "Install" (or "Install for all users").
- Mac: double-click the .ttf file, then click "Install Font".
Then restart Photoshop, Illustrator, Word or Canva desktop and pick "NTR" from the font list.
Files with [wght] in the name are variable fonts: one file holds every weight.
