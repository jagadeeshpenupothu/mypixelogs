Akaya Telivigala
================
Designer: Vaishnavi Murthy, Juan Luis Blanco
Licence: SIL Open Font License 1.1. Free for personal and commercial use, including print, logos and client work.
Source: Google Fonts (fonts.google.com/specimen/Akaya+Telivigala), downloaded from MyPixelogs (mypixelogs.netlify.app/assets/fonts/akaya-telivigala).

How to install
- Windows: right-click the .ttf file and choose "Install" (or "Install for all users").
- Mac: double-click the .ttf file, then click "Install Font".
Then restart Photoshop, Illustrator, Word or Canva desktop and pick "Akaya Telivigala" from the font list.
Files with [wght] in the name are variable fonts: one file holds every weight.
