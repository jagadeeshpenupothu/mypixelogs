Digital Marketing SEO Agency Flyer Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/seo-agency-flyer)

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  seo-agency-flyer.psd  Photoshop / Photopea: double-click a text layer to edit it; every part is its own layer
  seo-agency-flyer.ai   Adobe Illustrator: click the text and type
  seo-agency-flyer.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  seo-agency-flyer.eps  CorelDRAW / older Illustrator (File > Import)
  seo-agency-flyer.pdf  Print-ready A4 PDF
  seo-agency-flyer.png  A4 at 300 dpi (2480 x 3508)

Fonts: Poppins 700 (Google Fonts, SIL Open Font License); Poppins 600 (Google Fonts, SIL Open Font License); Poppins 400 (Google Fonts, SIL Open Font License); Poppins 800 (Google Fonts, SIL Open Font License); Poppins 500 (Google Fonts, SIL Open Font License)
Photos: Generated with Canva AI for MyPixelogs (Free to use, Canva)

Free for personal and commercial use. Replace the sample text with your own details.
