Digital Marketing SEO Agency Flyer Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/seo-agency-flyer)
Size: A4, 210 × 297 mm.

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  seo-agency-flyer.psd  Photoshop / Photopea: double-click a text layer to edit it
  seo-agency-flyer.ai   Adobe Illustrator (every side is a page): click the text and type
  seo-agency-flyer.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  seo-agency-flyer.eps  CorelDRAW / older Illustrator (File > Import)
  seo-agency-flyer.pdf  Print-ready PDF
  seo-agency-flyer.png  300 dpi

Fonts: Poppins 400 (Google Fonts, SIL Open Font License); Poppins 600 (Google Fonts, SIL Open Font License); Open Sans 400 (Google Fonts, SIL Open Font License); Open Sans 800 (Google Fonts, SIL Open Font License)
Images: Generated with Canva AI for MyPixelogs (Free to use, Canva); Alejandro Escamilla (CC0, StockSnap via Openverse); Peter Miranda (CC0, StockSnap via Openverse)

Free for personal and commercial use. Replace the sample text and logo with your own details.
