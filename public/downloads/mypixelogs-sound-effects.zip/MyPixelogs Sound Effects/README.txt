100 free sound effects for video editing, from MyPixelogs (mypixelogs.netlify.app/assets/sound-effects).

Licence: CC0 1.0 (public domain). Free for personal and commercial use, no credit needed.
Original sounds by Kenney (kenney.nl), converted to MP3.
