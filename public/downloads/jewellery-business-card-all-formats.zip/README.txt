Luxury Jewellery Business Card Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/jewellery-business-card)
Size: Business card, 90 × 54 mm (files include 3 mm bleed on every side; keep text 5 mm inside the trim line).

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  jewellery-business-card.psd / jewellery-business-card-back.psd  Photoshop / Photopea: double-click a text layer to edit it
  jewellery-business-card.ai   Adobe Illustrator (every side is a page): click the text and type
  jewellery-business-card.svg / jewellery-business-card-back.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  jewellery-business-card.eps / jewellery-business-card-back.eps  CorelDRAW / older Illustrator (File > Import)
  jewellery-business-card.pdf  Print-ready PDF (page 1 front, page 2 back)
  jewellery-business-card.png / jewellery-business-card-back.png  300 dpi

Fonts: Cormorant Garamond 700 (Google Fonts, SIL Open Font License); Montserrat 600 (Google Fonts, SIL Open Font License); Montserrat 500 (Google Fonts, SIL Open Font License); Cormorant Garamond 600 (Google Fonts, SIL Open Font License)

Free for personal and commercial use. Replace the sample text and logo with your own details.
