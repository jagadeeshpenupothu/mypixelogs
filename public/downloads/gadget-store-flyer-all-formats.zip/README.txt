Mobile & Electronics Store Flyer Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/gadget-store-flyer)

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  gadget-store-flyer.psd  Photoshop / Photopea: double-click a text layer to edit it; every part is its own layer
  gadget-store-flyer.ai   Adobe Illustrator: click the text and type
  gadget-store-flyer.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  gadget-store-flyer.eps  CorelDRAW / older Illustrator (File > Import)
  gadget-store-flyer.pdf  Print-ready A4 PDF
  gadget-store-flyer.png  A4 at 300 dpi (2480 x 3508)

Fonts: Outfit 700 (Google Fonts, SIL Open Font License); Outfit 500 (Google Fonts, SIL Open Font License); Outfit 600 (Google Fonts, SIL Open Font License); Montserrat 500 (Google Fonts, SIL Open Font License); Montserrat 600 (Google Fonts, SIL Open Font License)
Photos: Generated with ChatGPT for MyPixelogs (Free to use, ChatGPT)

Free for personal and commercial use. Replace the sample text with your own details.
