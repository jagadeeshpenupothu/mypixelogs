Mobile & Electronics Store Flyer Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/gadget-store-flyer)
Size: A4, 210 × 297 mm.

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  gadget-store-flyer.psd  Photoshop / Photopea: double-click a text layer to edit it
  gadget-store-flyer.ai   Adobe Illustrator (every side is a page): click the text and type
  gadget-store-flyer.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  gadget-store-flyer.eps  CorelDRAW / older Illustrator (File > Import)
  gadget-store-flyer.pdf  Print-ready PDF
  gadget-store-flyer.png  300 dpi

Fonts: Outfit 700 (Google Fonts, SIL Open Font License); Outfit 500 (Google Fonts, SIL Open Font License); Outfit 600 (Google Fonts, SIL Open Font License); Montserrat 500 (Google Fonts, SIL Open Font License); Montserrat 600 (Google Fonts, SIL Open Font License)
Images: Generated with ChatGPT for MyPixelogs (Free to use, ChatGPT)

Free for personal and commercial use. Replace the sample text and logo with your own details.
