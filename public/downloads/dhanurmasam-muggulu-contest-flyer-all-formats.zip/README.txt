Dhanurmasam Muggulu Contest Flyer Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/dhanurmasam-muggulu-contest-flyer)
Size: A4, 210 × 297 mm.

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  dhanurmasam-muggulu-contest-flyer.psd  Photoshop / Photopea: double-click a text layer to edit it
  dhanurmasam-muggulu-contest-flyer.ai   Adobe Illustrator (every side is a page): click the text and type
  dhanurmasam-muggulu-contest-flyer.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  dhanurmasam-muggulu-contest-flyer.eps  CorelDRAW / older Illustrator (File > Import)
  dhanurmasam-muggulu-contest-flyer.pdf  Print-ready PDF
  dhanurmasam-muggulu-contest-flyer.png  300 dpi

Fonts: Poppins 600 (Google Fonts, SIL Open Font License); Anton 400 (Google Fonts, SIL Open Font License); Poppins 500 (Google Fonts, SIL Open Font License); Poppins 400 (Google Fonts, SIL Open Font License)
Images: Generated with OpenAI image models for MyPixelogs (Free to use, OpenAI)

Free for personal and commercial use. Replace the sample text and logo with your own details.
