Navy and Gold Bakery ID Card Template – free from MyPixelogs (https://mypixelogs.netlify.app/templates/sona-bakery-id-card)
Size: ID card (CR80, PVC), 54 × 85.6 mm (files include 3 mm bleed on every side; keep text 5 mm inside the trim line).

FIRST install the fonts in the fonts folder (double-click each file > Install). Then every text is editable:
  sona-bakery-id-card.psd / sona-bakery-id-card-back.psd  Photoshop / Photopea: double-click a text layer to edit it
  sona-bakery-id-card.ai   Adobe Illustrator (every side is a page): click the text and type
  sona-bakery-id-card.svg / sona-bakery-id-card-back.svg  Inkscape, Figma, Illustrator; CorelDRAW: File > Import
  sona-bakery-id-card.eps / sona-bakery-id-card-back.eps  CorelDRAW / older Illustrator (File > Import)
  sona-bakery-id-card.pdf  Print-ready PDF (page 1 front, page 2 back)
  sona-bakery-id-card.png / sona-bakery-id-card-back.png  300 dpi

Fonts: Oswald 700 (Google Fonts, SIL Open Font License); Oswald 500 (Google Fonts, SIL Open Font License); Lato 700 (Google Fonts, SIL Open Font License); Lato 400 (Google Fonts, SIL Open Font License); Great Vibes 400 (Google Fonts, SIL Open Font License)

Free for personal and commercial use. Replace the sample text and logo with your own details.
